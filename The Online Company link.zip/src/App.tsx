/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { motion } from 'motion/react';
import { 
  Bot, 
  Workflow, 
  FileText, 
  Users, 
  Code, 
  ChevronRight, 
  ArrowRight,
  Zap,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle2,
  Mail,
  Phone,
  MapPin,
  MessageCircle
} from 'lucide-react';

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  initial: { opacity: 0 },
  whileInView: { opacity: 1 },
  viewport: { once: true },
  transition: { staggerChildren: 0.1 }
};

export default function App() {
  return (
    <div className="min-h-screen bg-brand-bg text-brand-text-p font-sans selection:bg-brand-accent selection:text-black overflow-x-hidden relative">
      
      {/* Background Grid & Effects */}
      <div className="glow top-[-100px] left-[-100px]"></div>
      <div className="glow bottom-[-100px] right-[-100px]"></div>

      {/* Navbar */}
      <nav className="fixed w-full z-50 top-0 border-b border-brand-line bg-brand-bg/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-10 h-16 flex items-center justify-between">
          <div className="font-bold text-lg tracking-tight flex items-center space-x-2">
            <span className="w-4 h-4 rounded-sm bg-brand-accent shadow-[0_0_10px_var(--color-brand-accent)] flex items-center justify-center text-black">
              <Bot size={12} />
            </span>
            <span>THE ONLINE COMPANY</span>
          </div>
          <div className="hidden md:flex items-center space-x-8 text-xs uppercase tracking-widest text-brand-text-s font-medium">
            <a href="#services" className="hover:text-brand-accent transition-colors">Services</a>
            <a href="#how-it-works" className="hover:text-brand-accent transition-colors">How it Works</a>
            <a href="#case-studies" className="hover:text-brand-accent transition-colors">Results</a>
            <a href="#pricing" className="hover:text-brand-accent transition-colors">Pricing</a>
          </div>
          <a 
            href="https://wa.me/923702744547" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hidden md:flex text-xs text-brand-text-p border-b border-brand-accent pb-0.5 hover:text-brand-accent transition-colors"
          >
            +92 370 2744547
          </a>
        </div>
      </nav>

      <main className="relative z-10 pt-16">
        
        {/* HERO SECTION */}
        <section className="relative min-h-[90vh] flex items-center justify-center px-10 overflow-hidden">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <div className="text-[11px] uppercase tracking-[0.2em] text-brand-accent mb-4 flex items-center justify-center gap-2">
                <div className="w-5 h-px bg-brand-accent"></div>
                Next-Gen Automation
                <div className="w-5 h-px bg-brand-accent"></div>
              </div>
              <h1 className="text-5xl md:text-[64px] font-semibold mb-6 leading-none tracking-[-0.04em]">
                Automate Your Business with <span className="text-brand-accent">Intelligent AI Solutions</span>
              </h1>
              <p className="text-base text-brand-text-s mb-8 max-w-lg mx-auto leading-[1.6]">
                We help companies save time, cut costs, and scale faster using custom AI automation systems. Less manual work, more revenue.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a 
            href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20learn%20more%20about%20your%20AI%20automation%20services." 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-7 py-3.5 rounded bg-brand-accent text-black font-semibold hover:opacity-90 transition-opacity flex items-center justify-center text-sm"
          >
            Get Free Consultation
            <ChevronRight size={16} className="ml-2" />
          </a>
          <a 
            href="#how-it-works"
            className="px-7 py-3.5 rounded border border-brand-line text-brand-text-p hover:bg-brand-surface transition-colors text-sm flex items-center justify-center"
          >
            See How It Works
          </a>
              </div>

              {/* Tech Stack Marquee */}
              <div className="mt-20 pt-10 border-t border-brand-line flex flex-wrap justify-center gap-8 md:gap-16 text-brand-text-p">
                <span className="font-semibold text-lg">OpenAI / GPT</span>
                <span className="font-semibold text-lg">Zapier / Make</span>
                <span className="font-semibold text-lg">Python</span>
                <span className="font-semibold text-lg">Airtable</span>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ABOUT US */}
        <section className="py-24 px-10 border-t border-brand-line" id="about">
          <div className="max-w-7xl mx-auto">
            <motion.div {...fadeIn} className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-[11px] uppercase tracking-[0.2em] text-brand-accent mb-4 flex items-center gap-2">
                  <div className="w-5 h-px bg-brand-accent"></div>
                  Who we are
                </h2>
                <h3 className="text-4xl md:text-5xl font-semibold mb-6 tracking-tight">We empower businesses to work smarter.</h3>
              </div>
              <div className="text-brand-text-s space-y-6 text-lg leading-[1.6]">
                <p>
                  We are an AI automation agency dedicated to helping businesses streamline operations using cutting-edge artificial intelligence. 
                  From chatbots to workflow automation, we design solutions that eliminate repetitive tasks and boost productivity.
                </p>
                <p className="font-medium text-brand-text-p border-l-2 border-brand-accent pl-4">
                  Our mission is simple: help you work smarter, not harder.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* SERVICES */}
        <section className="py-32 px-10 relative border-t border-brand-line" id="services">
          <div className="max-w-7xl mx-auto">
            <motion.div {...fadeIn} className="mb-16 text-center">
              <h2 className="text-[40px] font-semibold mb-4 tracking-[-0.04em]">Our Services</h2>
              <p className="text-brand-text-s max-w-2xl mx-auto">Transform your operations with our suite of custom AI-driven solutions.</p>
            </motion.div>

            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="whileInView"
              viewport={{ once: true }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {[
                {
                  icon: <Bot className="text-brand-accent" size={24} />,
                  title: "AI Chatbot Development",
                  features: ["Custom GPT-powered chatbots", "Website & WhatsApp integration", "24/7 customer support automation"]
                },
                {
                  icon: <Workflow className="text-brand-accent" size={24} />,
                  title: "Workflow Automation",
                  features: ["Automate repetitive business tasks", "CRM, email, and data sync", "Zapier / Make integrations"]
                },
                {
                  icon: <FileText className="text-brand-accent" size={24} />,
                  title: "AI Content Automation",
                  features: ["Blog writing automation", "Social media scheduling", "AI-generated marketing copy"]
                },
                {
                  icon: <Users className="text-brand-accent" size={24} />,
                  title: "Lead Generation Systems",
                  features: ["AI-powered funnels", "Automated outreach systems", "Email & LinkedIn automation"]
                },
                {
                  icon: <Code className="text-brand-accent" size={24} />,
                  title: "Custom AI Solutions",
                  features: ["Tailored AI tools for your business", "API integrations", "Internal AI assistants"]
                }
              ].map((service, idx) => (
                <motion.div key={idx} variants={fadeIn} className="card p-8 transition-all hover:border-brand-accent">
                  <div className="mb-6">
                    {service.icon}
                  </div>
                  <h3 className="text-sm font-semibold mb-2">{service.title}</h3>
                  <p className="text-[11px] text-brand-text-s leading-[1.4] mb-4">Core capabilities for your automation journey.</p>
                  <ul className="space-y-2 text-brand-text-s">
                    {service.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start">
                        <span className="mr-2 mt-1.5 block w-1 h-1 rounded-full bg-brand-accent shrink-0"></span>
                        <span className="text-xs">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="py-24 px-10 border-t border-brand-line" id="how-it-works">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div {...fadeIn}>
                <h2 className="text-[40px] font-semibold mb-6 tracking-[-0.04em]">How We Build Your AI Engine</h2>
                <p className="text-brand-text-s text-lg mb-8 leading-[1.6]">A streamlined 4-step process designed to integrate AI into your business with zero friction.</p>
                <div className="w-full aspect-square md:aspect-video rounded-lg overflow-hidden relative flex items-center justify-center border border-brand-line bg-brand-surface">
                  <div className="absolute inset-0 bg-[#00f2ff]/5 mix-blend-luminosity"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-bg to-transparent"></div>
                  <div className="relative z-10 w-32 h-32 rounded-full border border-brand-accent/30 flex items-center justify-center">
                    <div className="w-24 h-24 rounded-full border border-brand-accent/50 flex items-center justify-center animate-[spin_10s_linear_infinite]">
                       <div className="w-16 h-16 rounded-full bg-brand-accent opacity-20 blur-md"></div>
                    </div>
                    <Bot size={40} className="absolute text-brand-text-p" />
                  </div>
                </div>
              </motion.div>

              <div className="space-y-8 relative">
                <div className="absolute left-6 top-6 bottom-6 w-px bg-brand-line hidden md:block"></div>
                {[
                  { title: "Discovery Call", desc: "We understand your business needs and challenges." },
                  { title: "Strategy & Planning", desc: "We design a custom AI automation roadmap." },
                  { title: "Development", desc: "Our team builds and integrates your AI systems." },
                  { title: "Launch & Support", desc: "We deploy and continuously optimize your solution." }
                ].map((step, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="relative pl-0 md:pl-16 group"
                  >
                    <div className="md:absolute left-0 top-0 w-12 h-12 rounded bg-brand-surface border border-brand-line flex items-center justify-center text-brand-text-s font-semibold mb-4 md:mb-0 group-hover:border-brand-accent group-hover:text-brand-accent transition-colors">
                      0{idx + 1}
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                    <p className="text-brand-text-s text-sm leading-[1.6]">{step.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* BENEFITS & METRICS */}
        <section className="py-24 px-10 border-t border-brand-line overflow-hidden bg-brand-surface">
          <div className="max-w-7xl mx-auto">
            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="whileInView"
              viewport={{ once: true }}
              className="grid grid-cols-2 md:grid-cols-5 gap-6"
            >
              {[
                { value: "20+", label: "Hours Saved / Week", icon: <Clock size={20} className="text-brand-text-s group-hover:text-brand-accent transition-colors mb-4" /> },
                { value: "40%", label: "Reduced Costs", icon: <DollarSign size={20} className="text-brand-text-s group-hover:text-brand-accent transition-colors mb-4" /> },
                { value: "↑", label: "Increased Conversions", icon: <TrendingUp size={20} className="text-brand-text-s group-hover:text-brand-accent transition-colors mb-4" /> },
                { value: "24/7", label: "Active Automation", icon: <Bot size={20} className="text-brand-text-s group-hover:text-brand-accent transition-colors mb-4" /> },
                { value: "⚡", label: "Faster Growth", icon: <Zap size={20} className="text-brand-text-s group-hover:text-brand-accent transition-colors mb-4" /> },
              ].map((stat, idx) => (
                <motion.div key={idx} variants={fadeIn} className="group text-center p-6 border-r border-brand-line last:border-r-0 flex flex-col items-center justify-center bg-brand-surface hover:bg-brand-line/50 transition-colors">
                  <div className="flex justify-center">{stat.icon}</div>
                  <div className="text-2xl font-semibold text-brand-text-p mb-2">{stat.value}</div>
                  <div className="text-[10px] text-brand-text-s uppercase tracking-[0.1em]">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* CASE STUDIES */}
        <section className="py-32 px-10 border-t border-brand-line" id="case-studies">
          <div className="max-w-7xl mx-auto">
            <motion.div {...fadeIn} className="mb-16">
              <h2 className="text-[11px] uppercase tracking-[0.2em] text-brand-accent mb-4 flex items-center gap-2">
                <div className="w-5 h-px bg-brand-accent"></div>
                Proven Results
              </h2>
              <h3 className="text-[40px] font-semibold max-w-2xl tracking-[-0.04em]">Don't just take our word for it. Look at the data.</h3>
            </motion.div>

            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="whileInView"
              viewport={{ once: true }}
              className="grid md:grid-cols-3 gap-8"
            >
              {[
                { type: "E-commerce Brand", metric: "+35%", label: "Sales Increase", desc: "Automated customer support with custom chatbot." },
                { type: "Marketing Agency", metric: "15h", label: "Saved per week", desc: "Automated client onboarding and reporting." },
                { type: "SaaS Startup", metric: "-40%", label: "Support Tickets", desc: "Built AI support assistant for technical queries." },
              ].map((study, idx) => (
                <motion.div key={idx} variants={fadeIn} className="card p-8 group relative overflow-hidden flex flex-col justify-between h-[320px] transition-all hover:border-brand-accent">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-[50px] group-hover:bg-brand-accent/10 transition-all pointer-events-none"></div>
                  <div>
                    <div className="text-[10px] text-brand-text-s uppercase tracking-[0.1em] mb-4">{study.type}</div>
                    <div className="text-6xl font-semibold text-brand-text-p mb-2 tracking-tight">{study.metric}</div>
                    <div className="text-xs uppercase tracking-widest text-brand-accent font-semibold">{study.label}</div>
                  </div>
                  <p className="text-brand-text-s text-sm border-t border-brand-line pt-4">{study.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* PRICING */}
        <section className="py-32 px-10 relative border-t border-brand-line bg-brand-bg" id="pricing">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-2xl h-[400px] bg-brand-accent/5 blur-[150px] pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto relative z-10">
            <motion.div {...fadeIn} className="text-center mb-16">
              <h2 className="text-[40px] font-semibold mb-6 tracking-[-0.04em]">Transparent Pricing</h2>
              <p className="text-brand-text-s max-w-2xl mx-auto">Invest in automation systems that pay for themselves.</p>
            </motion.div>

            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="whileInView"
              viewport={{ once: true }}
              className="grid md:grid-cols-3 gap-8"
            >
              {/* Starter */}
              <motion.div variants={fadeIn} className="card p-8">
                <h3 className="text-sm font-semibold mb-2">Starter</h3>
                <div className="text-3xl font-semibold text-brand-text-p mb-6 tracking-tight">$500 <span className="text-sm text-brand-text-s font-normal line-through"> $1000</span></div>
                <ul className="space-y-4 mb-8 text-sm">
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Basic automation setup</li>
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> 1 Core workflow</li>
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Standard support</li>
                </ul>
                <a 
                  href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20learn%20more%20about%20your%20Starter%20automation%20plan." 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded border border-brand-line hover:bg-brand-surface transition-colors font-semibold text-sm flex justify-center"
                >
                  Get Started
                </a>
              </motion.div>

              {/* Growth - Highlighted */}
              <motion.div variants={fadeIn} className="card p-8 border-brand-accent relative shadow-[0_0_30px_rgba(0,242,255,0.05)]">
                <div className="absolute -top-3 left-8 bg-brand-accent text-[#000] text-[10px] font-bold px-3 py-1 rounded uppercase tracking-[0.1em]">
                  Most Popular
                </div>
                <h3 className="text-sm font-semibold mb-2 text-brand-text-p mt-2">Growth</h3>
                <div className="text-4xl font-semibold text-brand-text-p mb-6 tracking-tight">$1,500 <span className="text-base text-brand-text-s font-normal line-through"> $3000</span></div>
                <ul className="space-y-4 mb-8 text-sm">
                  <li className="flex items-center text-brand-text-p"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Multiple automations</li>
                  <li className="flex items-center text-brand-text-p"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Custom Chatbot included</li>
                  <li className="flex items-center text-brand-text-p"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> CRM & Email Integration</li>
                  <li className="flex items-center text-brand-text-p"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Priority support</li>
                </ul>
                <a 
                  href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20learn%20more%20about%20your%20Growth%20automation%20plan." 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded bg-brand-accent text-black font-semibold hover:opacity-90 transition-opacity text-sm flex justify-center"
                >
                  Choose Growth
                </a>
              </motion.div>

              {/* Pro */}
              <motion.div variants={fadeIn} className="card p-8">
                <h3 className="text-sm font-semibold mb-2">Pro</h3>
                <div className="text-3xl font-semibold text-brand-text-p mb-6 tracking-tight">Custom</div>
                <ul className="space-y-4 mb-8 text-sm">
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Full AI system architecture</li>
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Dedicated internal assistant</li>
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Custom API integrations</li>
                  <li className="flex items-center text-brand-text-s"><CheckCircle2 size={16} className="text-brand-accent mr-3 shrink-0" /> Ongoing maintenance</li>
                </ul>
                <a 
                  href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20learn%20more%20about%20your%20Custom%20Pro%20automation%20plan." 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded border border-brand-line hover:bg-brand-surface transition-colors font-semibold text-sm flex justify-center"
                >
                  Contact Us
                </a>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="py-32 px-10 relative overflow-hidden bg-brand-surface border-t border-brand-line" id="contact">
          <div className="absolute inset-0 bg-brand-accent/5 pointer-events-none mix-blend-luminosity"></div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center relative z-10 card p-16 md:p-24 flex flex-col items-center justify-center border-brand-accent/30 bg-brand-bg shadow-[0_0_50px_rgba(0,242,255,0.05)]"
          >
            <h2 className="text-4xl md:text-5xl font-semibold mb-6 tracking-[-0.04em]">Ready to Automate your Business?</h2>
            <p className="text-brand-text-s mb-10 max-w-xl mx-auto text-lg">
              Book a free consultation and discover how AI can transform your operations today.
            </p>
            <a 
              href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20book%20a%20free%20consultation%20call." 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-10 py-5 rounded bg-brand-accent text-[#000] font-semibold text-[15px] hover:opacity-90 transition-opacity inline-block"
            >
              Book a Call Now
            </a>
          </motion.div>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-brand-line bg-brand-bg pt-20 pb-10 px-10 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="md:col-span-2">
              <div className="font-bold text-lg tracking-tight flex items-center space-x-2 mb-6">
                <span className="w-5 h-5 rounded-sm bg-brand-accent shadow-[0_0_10px_var(--color-brand-accent)] flex items-center justify-center text-black">
                  <Bot size={14} />
                </span>
                <span className="text-brand-text-p uppercase tracking-wider">THE ONLINE COMPANY</span>
              </div>
              <p className="text-brand-text-s max-w-sm text-sm leading-[1.6]">
                We design AI solutions that eliminate repetitive tasks and help your business scale effortlessly.
              </p>
            </div>
            
            <div>
              <h4 className="text-brand-text-p mb-6 uppercase text-xs tracking-widest font-semibold">Navigation</h4>
              <ul className="space-y-4 text-brand-text-s text-sm">
                <li><a href="#" className="hover:text-brand-accent transition-colors">Home</a></li>
                <li><a href="#services" className="hover:text-brand-accent transition-colors">Services</a></li>
                <li><a href="#case-studies" className="hover:text-brand-accent transition-colors">Case Studies</a></li>
                <li><a href="#pricing" className="hover:text-brand-accent transition-colors">Pricing</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-brand-text-p mb-6 uppercase text-xs tracking-widest font-semibold">Contact</h4>
              <ul className="space-y-4 text-brand-text-s text-sm">
                <li className="flex items-center">
                  <Mail size={16} className="mr-3 text-brand-accent" />
                  <a href="mailto:theonlinecompany985@gmail.com" className="hover:text-brand-text-p transition-colors break-all">
                    theonlinecompany985@gmail.com
                  </a>
                </li>
                <li className="flex items-center">
                  <Phone size={16} className="mr-3 text-brand-accent" />
                  <a href="https://wa.me/923702744547" target="_blank" rel="noopener noreferrer" className="hover:text-brand-text-p transition-colors">
                    +92 370 2744547
                  </a>
                </li>
                <li className="flex items-center">
                  <MapPin size={16} className="mr-3 text-brand-accent" />
                  <span>Nawabshah / Remote</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-brand-line pt-8 flex flex-col md:flex-row items-center justify-between text-brand-text-s text-[11px]">
            <p>&copy; {new Date().getFullYear()} The Online Company AI Automation Agency. All rights reserved.</p>
            <div className="mt-4 md:mt-0 flex space-x-6">
              <a href="#" className="hover:text-brand-text-p transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-brand-text-p transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/923702744547?text=Hi!%20I%20would%20like%20to%20learn%20more%20about%20your%20services."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 md:bottom-10 md:right-10 z-50 flex items-center justify-center w-14 h-14 bg-[#25D366] text-white rounded-full shadow-[0_4px_14px_rgba(37,211,102,0.4)] hover:scale-110 hover:shadow-[0_6px_20px_rgba(37,211,102,0.6)] transition-all duration-300"
        aria-label="Chat with us on WhatsApp"
      >
        <MessageCircle size={28} />
      </a>

    </div>
  );
}
